#!/bin/sh
sudo gdb-multiarch -ex "target remote 127.0.0.1:11111" -ex "file ./fs/bin/httpd_patch"
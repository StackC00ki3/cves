#!/bin/sh
sudo chroot ./ /qemu-arm-static -g 11111 /bin/httpd_patch 